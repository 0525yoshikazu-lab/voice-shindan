# 声診断

マイクに向かって話すだけで、声の高さ・音色から6タイプに診断するWebアプリ。

## こちらで用意しておくもの

デプロイ作業自体はこちらでも手伝えますが、以下はあなたのアカウントで用意する必要があります。

1. **GitHubアカウント**(無料)
   - このプロジェクトを置くリポジトリを作るため
2. **Vercel または Netlify のアカウント**(無料、GitHubアカウントでサインアップ可)
   - どちらでもOKです。迷ったらVercelが手順がシンプルでおすすめ
3. **(任意)独自ドメイン**
   - `voice-shindan.vercel.app` のようなデフォルトURLで良ければ不要
   - 独自ドメインが欲しい場合はお名前.com / Google Domains などで取得(年数百〜数千円)
4. **(デプロイ後にやること)`index.html` 内のURL置き換え**
   - `REPLACE_WITH_YOUR_DOMAIN` という文字列が2箇所(og:image, og:url)あるので、実際に発行されたURLに差し替えてください
   - 例:`https://voice-shindan.vercel.app/ogp.png`

## デプロイ手順(Vercelの場合)

1. このフォルダをGitHubリポジトリにpush
2. https://vercel.com にログインし、「Add New Project」→ そのリポジトリを選択
3. フレームワークは自動で「Vite」と認識されるはず(されなければ Framework Preset で Vite を選択)
4. 「Deploy」をクリックすると数十秒でURLが発行されます
5. 発行されたURLを `index.html` の `REPLACE_WITH_YOUR_DOMAIN` に反映し、再度push(自動で再デプロイされます)

## デプロイ手順(Netlifyの場合)

1. このフォルダをGitHubリポジトリにpush
2. https://app.netlify.com で「Add new site」→「Import an existing project」
3. Build command: `npm run build` / Publish directory: `dist` を指定
4. 「Deploy site」をクリック

## ローカルで動作確認したい場合

Node.js(18以上推奨)がインストールされていれば、以下で確認できます。

```bash
npm install
npm run dev
```

## ファイル構成

```
voice-diagnosis-app/
├── index.html          # OGP/Twitter Card設定込みのHTML
├── package.json
├── vite.config.js
├── public/
│   └── ogp.png          # X等でリンクを貼った時に表示されるカード画像(1200x630)
└── src/
    ├── main.jsx         # エントリーポイント
    ├── App.jsx           # アプリ本体
    └── index.css         # 最低限のグローバルCSS
```
